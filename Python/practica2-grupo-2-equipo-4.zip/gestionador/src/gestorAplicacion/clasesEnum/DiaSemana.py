from enum import Enum

# Esto sirve para los planes de alimentación y de ejercicio semanales.

class DiaSemana(Enum):
    LUNES = "LUNES"
    MARTES = "MARTES"
    MIERCOLES = "MIERCOLES"
    JUEVES = "JUEVES"
    VIERNES = "VIERNES"
    SABADO = "SABADO"
    DOMINGO = "DOMINGO"
    