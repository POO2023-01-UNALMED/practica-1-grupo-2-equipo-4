from enum import Enum

# Cada comida puede ser de uno de los tres tipos.

class TipoComida(Enum):
    DESAYUNO = "DESAYUNO"
    ALMUERZO = "ALMUERZO"
    CENA = "CENA"
